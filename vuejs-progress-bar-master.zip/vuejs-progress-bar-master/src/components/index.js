import Vue from 'vue'

import ProgressBar from './ProgressBar.vue'

Vue.component('ProgressBar', ProgressBar)

export { ProgressBar }

export default ProgressBar
